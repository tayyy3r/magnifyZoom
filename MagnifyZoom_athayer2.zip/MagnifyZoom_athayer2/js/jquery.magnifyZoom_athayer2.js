;(function($, window, undefined){

  //Constructor
  $.MagnifyZoom = function(options, imageContainer){

    this.$imageContainer = $(imageContainer);
    this._init(options)

  }//End of Constructor

  //Default Options Property
  $.MagnifyZoom.defaults = {
    width: 300,   
    height: 300,
    cornerRounding: '50%'   
  }//End Defaults

  //MagnifyZoom's Methods
  $.MagnifyZoom.prototype = {

    //_init method declaration
    _init: function(options){

      imageObject = new Image();

      imageObject.src = this.$imageContainer.children('img').attr('src');

      this.options = $.extend(true, {}, $.MagnifyZoom.defaults, options);

      this.nativeWidth = imageObject.width

      this.nativeHeight = imageObject.height

      $glass = $('.large');

      $smallImage = $('.small');     

      this._getLocation();

    },//End of _init()

    //_getLocation method declaration
    _getLocation: function(){

      let self = this;

      $('.magnify').mousemove(function(e){

        $target = $(this);

        magnifyOffset = $target.offset();

        mouseX = e.pageX - magnifyOffset.left;
        mouseY = e.pageY - magnifyOffset.top;

        self._zoom($target);

      });

    },//End of _getLocation()

    //_zoom method declaration
    _zoom: function($target){

      if (mouseX <= 0 || mouseX >= $smallImage.width() || mouseY <= 0 || mouseY >= $smallImage.height()) {

        $glass.stop(true).fadeOut();

      } else {

        $glass.stop(true).fadeIn();

      }

      if($glass.is(":visible")){

        glassWidth = $glass.width()
        glassHeight = $glass.height()
        halfGlassWidth = glassWidth / 2,
        halfGlassHeight = glassHeight / 2,
  
        posX = mouseX - halfGlassWidth;
        posY = mouseY - halfGlassHeight;
  
        rx = Math.round(mouseX / $smallImage.width() * this.nativeWidth - halfGlassWidth) * -1;
        ry = Math.round(mouseY / $smallImage.height() * this.nativeHeight - halfGlassHeight) * -1;
  
        $glass.css({
          cursor: 'none',
          width: this.options.width,
          height: this.options.height, 
          borderRadius: this.options.cornerRounding,
          top: posY,
          left: posX,
          backgroundPosition: rx + 'px ' + ry + 'px'
        });
  
      }

    }//End _zoom()

  }//End of Method Declarations

  $.fn.magnifyZoom = function(options){

    if(typeof options === 'string'){

      var args = Array.prototype.slice.call(arguments, 1);

      this.each(function(){
        var instance = $.data(this, 'magnifyZoom');

        if (!instance) {
          logError( "cannot call methods on magnifyZoom prior to initialization; " +
					"attempted to call method '" + options + "'" );
					return;
        }

        if ( !$.isFunction( instance[options] ) || options.charAt(0) === "_" ) {
					logError( "no such method '" + options + "' for magnifyZoom instance" );
					return;
				}

        instance[options].apply(instance, args)

      });
    }
    else {
      this.each(function(){
        var instance = $.data(this, 'magnifyZoom');

        if(instance){
          instance._init();
        } else {
          instance = $.data(this, 'magnifyZoom', new $.MagnifyZoom(options, this));
        }
      })
    }
    return this;
  };

})(jQuery, window);